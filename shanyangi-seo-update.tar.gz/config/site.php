<?php

/*
|--------------------------------------------------------------------------
| Site Settings
|--------------------------------------------------------------------------
|
| Contact numbers are used by the mobile bottom navigation (WhatsApp + Call
| buttons); when one is missing, its button falls back to the contact page.
|
*/

return [

    // Brand name in page titles, link previews and structured data.
    'name' => 'Shanyangi Adventures',

    // Contact details below are the starting values. Once saved in the admin
    // (Pages → Site settings → Contact details) the admin values are used instead.

    // International format, digits only or with "+", e.g. 255712345678
    'whatsapp' => env('SITE_WHATSAPP') ?: '255787156775',

    'whatsapp_message' => env('SITE_WHATSAPP_MESSAGE', 'Hi Shanyangi Adventures! I am interested in booking a safari.'),

    // Dialable phone number, e.g. +255712345678
    'phone' => env('SITE_PHONE') ?: '+255 787 156 775',

    // Shown on the contact page and in the footer (each line is hidden while empty).
    'email' => env('SITE_EMAIL') ?: 'info@shanyangiadventures.co.tz',

    // Where new bookings are emailed (comma-separate several). The admin setting under
    // Pages → Site settings → Booking emails takes priority; SITE_EMAIL is the last fallback.
    'bookings_email' => env('BOOKINGS_EMAIL'),

    'address' => env('SITE_ADDRESS'),

    // Office time zone: times shown in the admin (stored as UTC).
    'timezone' => env('SITE_TIMEZONE', 'Africa/Dar_es_Salaam'),

    // Live chat bubble on every page (answered in the admin under Bookings → Live chat).
    'live_chat' => (bool) env('SITE_LIVE_CHAT', true),

    // Footer partner / affiliation logos (files in public/images). 'url' is optional:
    // set it to link a logo, e.g. to your SafariBookings profile.
    'partners' => [
        ['name' => 'SafariBookings', 'logo' => 'images/s-b-logo_pdf.webp', 'url' => env('SITE_SAFARIBOOKINGS_URL')],
        ['name' => 'Tanzania National Parks', 'logo' => 'images/taifa-logo.webp', 'url' => null],
        ['name' => 'Tanzania Tourist Board', 'logo' => 'images/TTB-Logo.webp', 'url' => null],
        ['name' => 'Tanzania Association of Tour Operators (TATO)', 'logo' => 'images/Logo-TATO-Tanzania-Association-of-Tour-Operators-tr.webp', 'url' => null],
        ['name' => 'African Travel & Tourism Association (ATTA)', 'logo' => 'images/atta-logo.webp', 'url' => null],
    ],

    // "We accept" row in the footer (image in public/images). Set to null to hide it.
    'payment_cards' => [
        'image' => 'images/payment-cards.webp',
        'label' => 'Visa, Mastercard, American Express and Discover',
    ],

    // Footer social icons: only the ones with a URL are shown.
    // Defaults for the admin's Site settings page (App\Support\SocialLinks).
    'social' => [
        'instagram' => env('SITE_INSTAGRAM'),
        'facebook' => env('SITE_FACEBOOK'),
        'linkedin' => env('SITE_LINKEDIN'),
        'tiktok' => env('SITE_TIKTOK'),
        'youtube' => env('SITE_YOUTUBE'),
    ],

    /*
    | Home hero background (protected media, see config/media.php).
    | hero_stream: name of an encrypted stream built with
    |   php artisan media:encrypt-video <file> hero
    | hero_poster: image under media/images, shown while the video loads and
    |   to visitors who prefer reduced motion.
    */
    'hero_stream' => env('SITE_HERO_STREAM', 'hero'),

    'hero_poster' => env('SITE_HERO_POSTER', 'hero-poster.jpg'),

];
