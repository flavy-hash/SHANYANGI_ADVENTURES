<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // One address for search engines: other hosts 301 to APP_URL (CANONICAL_REDIRECT=true).
        $middleware->prepend(\App\Http\Middleware\CanonicalHost::class);

        // Anonymous visitor activity log (admin: Visitor activity). See config/analytics.php.
        $middleware->web(append: [
            \App\Http\Middleware\LogPageView::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
