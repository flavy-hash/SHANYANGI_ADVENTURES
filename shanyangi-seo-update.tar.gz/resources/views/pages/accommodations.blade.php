@extends('layouts.app')

@section('title', ($activeLabel ? $activeLabel.' ' : '').'Accommodation')
@section('description', 'Safari lodges, tented camps and beach stays across Tanzania'.($locations ? ': '.implode(', ', $locations) : '').'.')

@section('content')
    <x-page-hero
        title="Where You'll Stay"
        kicker="Lodges, Camps & Beach Stays"
        subtitle="Hand-picked places to rest between adventures, from canvas under the stars to villas by the ocean."
        image="site/accommodation-mountain-lounge.webp"
        focus="center 40%"
        :crumbs="array_filter([['label' => 'Accommodation', 'url' => route('accommodations')], $activeLabel ? ['label' => $activeLabel] : null])"
    />

    <section class="bg-tm-beige py-14 sm:py-20" aria-labelledby="stays-list-title">
        <div class="tm-container">
            <p class="tm-section-kicker">Accommodation</p>
            <h2 id="stays-list-title" class="tm-section-title">{{ $activeLabel ? 'Stays in '.$activeLabel : 'Stays for Every Route' }}</h2>
            <div class="tm-divider" aria-hidden="true"></div>
            <p class="tm-section-subtitle">
                We match lodges and camps to your route, comfort level and budget. These are some of the places we love to use.
            </p>

            <x-filter-chips :filters="$filters" label="Filter stays by location" />

            @if ($stays->isNotEmpty())
                <div class="tm-card-grid mt-10">
                    @foreach ($stays as $stay)
                        <x-info-card
                            :title="$stay->name"
                            :href="$stay->url"
                            :image="$stay->image"
                            :pill="$stay->location"
                            :chips="array_values(array_filter([$stay->type, $stay->level]))"
                            :text="$stay->description"
                            link-label="View stay & photos"
                        />
                    @endforeach
                </div>
            @else
                <p class="tm-empty">No stays listed here yet. <a href="{{ route('contact') }}#request">Ask us</a> for options in this area.</p>
            @endif
        </div>
    </section>

    <x-cta-band
        title="Need help choosing where to stay?"
        text="Tell us your route and comfort level, and we will recommend lodges and camps that fit your budget."
    />
@endsection
